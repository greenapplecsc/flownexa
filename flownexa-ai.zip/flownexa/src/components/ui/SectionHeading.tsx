export default function SectionHeading({ eyebrow, title }: { eyebrow: string; title: string }) {
  return (
    <div className="mb-10">
      <div className="font-mono text-xs tracking-widest uppercase mb-3" style={{ color: "var(--accent, #5B4FE9)" }}>
        {eyebrow}
      </div>
      <h2 className="font-display text-3xl font-semibold tracking-tight">{title}</h2>
    </div>
  );
}
