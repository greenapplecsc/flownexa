import { ArrowUpRight, ArrowDownRight } from "lucide-react";
import Card from "./Card";
import { SUCCESS, DANGER } from "@/utils/tokens";

interface StatCardProps {
  label: string;
  value: string;
  delta: string;
  up: boolean;
}

export default function StatCard({ label, value, delta, up }: StatCardProps) {
  return (
    <Card className="p-5">
      <div className="text-xs mb-2" style={{ color: "var(--muted)" }}>
        {label}
      </div>
      <div className="flex items-end justify-between">
        <span className="font-display text-2xl font-semibold">{value}</span>
        <span className="flex items-center gap-0.5 text-xs font-medium" style={{ color: up ? SUCCESS : DANGER }}>
          {up ? <ArrowUpRight size={13} /> : <ArrowDownRight size={13} />}
          {delta}
        </span>
      </div>
    </Card>
  );
}
