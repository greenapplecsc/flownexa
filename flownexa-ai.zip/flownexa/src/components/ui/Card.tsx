import type { HTMLAttributes, ReactNode } from "react";
import { cn } from "@/utils/cn";

interface CardProps extends HTMLAttributes<HTMLDivElement> {
  children: ReactNode;
  hover?: boolean;
}

export default function Card({ children, className, hover, style, ...rest }: CardProps) {
  return (
    <div
      className={cn("rounded-xl p-6", hover && "card-hover", className)}
      style={{ background: "var(--surface)", border: "1px solid var(--border)", ...style }}
      {...rest}
    >
      {children}
    </div>
  );
}
