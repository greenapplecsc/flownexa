import type { ButtonHTMLAttributes, ReactNode } from "react";
import { cn } from "@/utils/cn";
import { ACCENT } from "@/utils/tokens";

interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: "primary" | "outline" | "ghost";
  children: ReactNode;
}

export default function Button({ variant = "primary", className, children, style, ...rest }: ButtonProps) {
  const base = "px-5 py-2.5 rounded-full text-sm font-medium inline-flex items-center gap-2 transition-transform active:scale-95";

  if (variant === "primary") {
    return (
      <button
        className={cn(base, className)}
        style={{ background: ACCENT, color: "#fff", ...style }}
        {...rest}
      >
        {children}
      </button>
    );
  }

  if (variant === "outline") {
    return (
      <button
        className={cn(base, className)}
        style={{ border: "1px solid var(--border)", color: "var(--text)", ...style }}
        {...rest}
      >
        {children}
      </button>
    );
  }

  return (
    <button className={cn(base, "bg-transparent", className)} style={{ color: "var(--muted)", ...style }} {...rest}>
      {children}
    </button>
  );
}
