import { useTheme } from "@/context/ThemeContext";
import { ACCENT } from "@/utils/tokens";

const NODES = [
  { label: "lead.in", x: 20 },
  { label: "agent.run", x: 200 },
  { label: "action.done", x: 380 },
];

export default function FlowPulse() {
  const { dark } = useTheme();
  const line = dark ? "#2A2A3A" : "#DEDCF0";
  const nodeBg = dark ? "#151520" : "#FFFFFF";
  const nodeBorder = dark ? "#33334A" : "#DEDCF0";
  const textCol = dark ? "#B8B6C8" : "#5B5876";

  return (
    <svg viewBox="0 0 420 90" className="w-full max-w-md" aria-hidden="true">
      <defs>
        <linearGradient id="pulseGrad" x1="0" x2="1">
          <stop offset="0%" stopColor={ACCENT} stopOpacity="0" />
          <stop offset="50%" stopColor={ACCENT} stopOpacity="1" />
          <stop offset="100%" stopColor={ACCENT} stopOpacity="0" />
        </linearGradient>
      </defs>
      <line x1="20" y1="45" x2="380" y2="45" stroke={line} strokeWidth="2" />
      <rect x="0" y="43" width="60" height="4" fill="url(#pulseGrad)">
        <animate attributeName="x" values="-60;420" dur="2.8s" repeatCount="indefinite" />
      </rect>
      {NODES.map((n, i) => (
        <g key={n.label}>
          <rect x={n.x - 20} y="25" width="40" height="40" rx="10" fill={nodeBg} stroke={nodeBorder} strokeWidth="1.5" />
          <circle cx={n.x} cy="45" r="4" fill={ACCENT}>
            <animate attributeName="opacity" values="0.3;1;0.3" dur="2.8s" begin={`${i * 0.9}s`} repeatCount="indefinite" />
          </circle>
          <text x={n.x} y="80" textAnchor="middle" fontFamily="JetBrains Mono" fontSize="10" fill={textCol}>
            {n.label}
          </text>
        </g>
      ))}
    </svg>
  );
}
