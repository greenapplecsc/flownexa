export interface ModuleColumn {
  key: string;
  label: string;
  isBadge?: boolean;
}

export interface ModuleConfig {
  title: string;
  description: string;
  columns: ModuleColumn[];
  rows: Record<string, string | number>[];
}

export const CMS_MODULES: Record<string, ModuleConfig> = {
  content: {
    title: "Website Content",
    description: "Edit the copy blocks that populate the public site's sections.",
    columns: [
      { key: "section", label: "Section" },
      { key: "page", label: "Page" },
      { key: "updated", label: "Last updated" },
      { key: "status", label: "Status", isBadge: true },
    ],
    rows: [
      { section: "Hero headline", page: "Home", updated: "Jul 20, 2026", status: "Published" },
      { section: "CTA copy", page: "Home", updated: "Jul 18, 2026", status: "Published" },
      { section: "About intro", page: "About", updated: "Jul 12, 2026", status: "Draft" },
    ],
  },
  services: {
    title: "Services",
    description: "Manage the service cards shown on the public site.",
    columns: [
      { key: "name", label: "Service" },
      { key: "category", label: "Category" },
      { key: "leads", label: "Leads generated" },
      { key: "status", label: "Status", isBadge: true },
    ],
    rows: [
      { name: "AI Chatbots", category: "Conversational", leads: 42, status: "Published" },
      { name: "WhatsApp Automation", category: "Conversational", leads: 31, status: "Published" },
      { name: "AI Calling Agents", category: "Voice", leads: 18, status: "Published" },
      { name: "Workflow Automation", category: "Operations", leads: 27, status: "Draft" },
    ],
  },
  pricing: {
    title: "Pricing Plans",
    description: "Control what appears in the public pricing section.",
    columns: [
      { key: "plan", label: "Plan" },
      { key: "price", label: "Price" },
      { key: "subscribers", label: "Active subscribers" },
      { key: "status", label: "Status", isBadge: true },
    ],
    rows: [
      { plan: "Starter", price: "$1,900/mo", subscribers: 14, status: "Published" },
      { plan: "Growth", price: "$4,500/mo", subscribers: 19, status: "Published" },
      { plan: "Enterprise", price: "Custom", subscribers: 5, status: "Published" },
    ],
  },
  faqs: {
    title: "FAQs",
    description: "Frequently asked questions shown on the public site.",
    columns: [
      { key: "question", label: "Question" },
      { key: "category", label: "Category" },
      { key: "status", label: "Status", isBadge: true },
    ],
    rows: [
      { question: "How long does setup take?", category: "Onboarding", status: "Published" },
      { question: "Do you integrate with our CRM?", category: "Technical", status: "Published" },
      { question: "What's included in Growth?", category: "Pricing", status: "Draft" },
    ],
  },
  "case-studies": {
    title: "Case Studies",
    description: "Client success stories featured on the public site.",
    columns: [
      { key: "client", label: "Client" },
      { key: "industry", label: "Industry" },
      { key: "result", label: "Result" },
      { key: "status", label: "Status", isBadge: true },
    ],
    rows: [
      { client: "Harbor Realty Group", industry: "Real Estate", result: "+38% qualified leads", status: "Published" },
      { client: "Meridian Dental", industry: "Healthcare", result: "3hrs saved daily", status: "Published" },
      { client: "Coastal Logistics Co.", industry: "Logistics", result: "-22% response time", status: "Draft" },
    ],
  },
  blog: {
    title: "Blog",
    description: "Articles and posts published on the public blog.",
    columns: [
      { key: "title", label: "Title" },
      { key: "author", label: "Author" },
      { key: "published", label: "Published" },
      { key: "status", label: "Status", isBadge: true },
    ],
    rows: [
      { title: "5 signs you're ready for AI automation", author: "mk", published: "Jul 14, 2026", status: "Published" },
      { title: "WhatsApp automation for local businesses", author: "mk", published: "Jul 2, 2026", status: "Published" },
      { title: "Inside our voice agent stack", author: "mk", published: "—", status: "Draft" },
    ],
  },
  testimonials: {
    title: "Testimonials",
    description: "Client quotes displayed across the public site.",
    columns: [
      { key: "author", label: "Author" },
      { key: "company", label: "Company" },
      { key: "rating", label: "Rating" },
      { key: "status", label: "Status", isBadge: true },
    ],
    rows: [
      { author: "J. Alvarez", company: "Harbor Realty Group", rating: "5.0", status: "Published" },
      { author: "R. Chen", company: "Meridian Dental", rating: "4.8", status: "Published" },
      { author: "S. Okafor", company: "Voss & Kline Law", rating: "5.0", status: "Draft" },
    ],
  },
  team: {
    title: "Team Members",
    description: "People shown on the public About page.",
    columns: [
      { key: "name", label: "Name" },
      { key: "role", label: "Role" },
      { key: "status", label: "Status", isBadge: true },
    ],
    rows: [
      { name: "mk", role: "Founder", status: "Published" },
      { name: "A. Novak", role: "Solutions Architect", status: "Published" },
      { name: "T. Ibarra", role: "Client Success Lead", status: "Published" },
    ],
  },
  leads: {
    title: "Contact Form Leads",
    description: "Submissions from the public contact form.",
    columns: [
      { key: "name", label: "Name" },
      { key: "email", label: "Email" },
      { key: "submitted", label: "Submitted" },
      { key: "status", label: "Status", isBadge: true },
    ],
    rows: [
      { name: "Dana Whitfield", email: "dana@northbay.co", submitted: "Jul 24, 2026", status: "New" },
      { name: "Priya Menon", email: "priya@quorumtax.com", submitted: "Jul 23, 2026", status: "New" },
      { name: "Leo Fischer", email: "leo@fischerlaw.com", submitted: "Jul 20, 2026", status: "Contacted" },
    ],
  },
  enquiries: {
    title: "Client Enquiries",
    description: "Detailed enquiries from prospective clients.",
    columns: [
      { key: "company", label: "Company" },
      { key: "interest", label: "Interested in" },
      { key: "submitted", label: "Submitted" },
      { key: "status", label: "Status", isBadge: true },
    ],
    rows: [
      { company: "Northbay Property Group", interest: "Real Estate lead bot", submitted: "Jul 22, 2026", status: "New" },
      { company: "Fischer & Doyle Law", interest: "Client intake automation", submitted: "Jul 19, 2026", status: "Contacted" },
    ],
  },
  "demo-requests": {
    title: "Demo Requests",
    description: "Requests to view live demo projects.",
    columns: [
      { key: "name", label: "Name" },
      { key: "demo", label: "Demo requested" },
      { key: "submitted", label: "Submitted" },
      { key: "status", label: "Status", isBadge: true },
    ],
    rows: [
      { name: "Marcus Yu", demo: "Restaurant AI Chatbot", submitted: "Jul 24, 2026", status: "New" },
      { name: "Elena Petrov", demo: "AI Voice Receptionist", submitted: "Jul 21, 2026", status: "Scheduled" },
    ],
  },
  media: {
    title: "Media Library",
    description: "Images and files used across the public site.",
    columns: [
      { key: "file", label: "File" },
      { key: "type", label: "Type" },
      { key: "size", label: "Size" },
      { key: "uploaded", label: "Uploaded" },
    ],
    rows: [
      { file: "hero-flow-diagram.svg", type: "SVG", size: "12 KB", uploaded: "Jul 20, 2026" },
      { file: "case-study-harbor.jpg", type: "JPG", size: "340 KB", uploaded: "Jul 15, 2026" },
      { file: "team-headshot-mk.jpg", type: "JPG", size: "210 KB", uploaded: "Jul 10, 2026" },
    ],
  },
  users: {
    title: "User Management",
    description: "People with access to this admin dashboard.",
    columns: [
      { key: "name", label: "Name" },
      { key: "email", label: "Email" },
      { key: "role", label: "Role" },
      { key: "status", label: "Status", isBadge: true },
    ],
    rows: [
      { name: "mk", email: "admin@flownexa.ai", role: "Admin", status: "Active" },
      { name: "A. Novak", email: "novak@flownexa.ai", role: "Editor", status: "Active" },
    ],
  },
  roles: {
    title: "Roles & Permissions",
    description: "Define what each role can view and edit.",
    columns: [
      { key: "role", label: "Role" },
      { key: "access", label: "Access level" },
      { key: "members", label: "Members" },
      { key: "status", label: "Status", isBadge: true },
    ],
    rows: [
      { role: "Admin", access: "Full access", members: 1, status: "Active" },
      { role: "Editor", access: "Content + leads only", members: 1, status: "Active" },
      { role: "Viewer", access: "Read-only", members: 0, status: "Active" },
    ],
  },
};
