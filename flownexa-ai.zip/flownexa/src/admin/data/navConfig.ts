import type { LucideIcon } from "lucide-react";
import {
  LayoutDashboard, FileText, Wrench, DollarSign, HelpCircle, Briefcase,
  Newspaper, Quote, Users, Inbox, MessageSquare, PhoneCall, Image,
  Search as SearchIcon, Settings, UserCog, ShieldCheck,
} from "lucide-react";

export interface AdminNavSection {
  path: string;
  label: string;
  icon: LucideIcon;
}

export const ADMIN_NAV: AdminNavSection[] = [
  { path: "/admin", label: "Overview", icon: LayoutDashboard },
  { path: "/admin/content", label: "Website Content", icon: FileText },
  { path: "/admin/services", label: "Services", icon: Wrench },
  { path: "/admin/pricing", label: "Pricing Plans", icon: DollarSign },
  { path: "/admin/faqs", label: "FAQs", icon: HelpCircle },
  { path: "/admin/case-studies", label: "Case Studies", icon: Briefcase },
  { path: "/admin/blog", label: "Blog", icon: Newspaper },
  { path: "/admin/testimonials", label: "Testimonials", icon: Quote },
  { path: "/admin/team", label: "Team Members", icon: Users },
  { path: "/admin/leads", label: "Contact Form Leads", icon: Inbox },
  { path: "/admin/enquiries", label: "Client Enquiries", icon: MessageSquare },
  { path: "/admin/demo-requests", label: "Demo Requests", icon: PhoneCall },
  { path: "/admin/media", label: "Media Library", icon: Image },
  { path: "/admin/seo", label: "SEO Settings", icon: SearchIcon },
  { path: "/admin/settings", label: "Website Settings", icon: Settings },
  { path: "/admin/users", label: "User Management", icon: UserCog },
  { path: "/admin/roles", label: "Roles & Permissions", icon: ShieldCheck },
];
