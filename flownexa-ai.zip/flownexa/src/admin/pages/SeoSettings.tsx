import { useState } from "react";
import Card from "@/components/ui/Card";
import Button from "@/components/ui/Button";

const fields: { key: string; label: string; placeholder: string }[] = [
  { key: "metaTitle", label: "Default meta title", placeholder: "FlowNexa AI — Automate Smarter. Scale Faster." },
  { key: "metaDescription", label: "Default meta description", placeholder: "AI chatbots, voice agents, and workflow automation for high-ticket businesses." },
  { key: "ogImage", label: "Open Graph image URL", placeholder: "https://flownexa.ai/og-image.png" },
  { key: "twitterHandle", label: "Twitter/X handle", placeholder: "@flownexaai" },
];

export default function SeoSettings() {
  const [values, setValues] = useState<Record<string, string>>({});

  return (
    <div className="space-y-5 max-w-2xl">
      <div>
        <h1 className="font-display text-xl font-semibold">SEO Settings</h1>
        <p className="text-sm mt-1" style={{ color: "var(--muted)" }}>
          Controls meta tags, Open Graph data, and schema markup for the public site.
        </p>
      </div>

      <Card className="space-y-4">
        {fields.map((f) => (
          <div key={f.key}>
            <label className="text-xs font-medium block mb-1.5" style={{ color: "var(--muted)" }}>{f.label}</label>
            <input
              value={values[f.key] ?? ""}
              onChange={(e) => setValues((v) => ({ ...v, [f.key]: e.target.value }))}
              placeholder={f.placeholder}
              className="w-full px-3 py-2.5 rounded-lg text-sm outline-none"
              style={{ background: "var(--bg)", border: "1px solid var(--border)", color: "var(--text)" }}
            />
          </div>
        ))}
        <Button variant="primary">Save changes</Button>
      </Card>
    </div>
  );
}
