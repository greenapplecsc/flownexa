import { ChevronDown } from "lucide-react";
import { LineChart, Line, ResponsiveContainer, XAxis, Tooltip } from "recharts";
import Card from "@/components/ui/Card";
import Badge from "@/components/ui/Badge";
import StatCard from "@/components/ui/StatCard";
import { ACCENT, STATUS_COLORS } from "@/utils/tokens";

const stats = [
  { label: "Active clients", value: "38", delta: "+4", up: true },
  { label: "MRR", value: "$61,200", delta: "+12%", up: true },
  { label: "Open tickets", value: "7", delta: "-2", up: false },
  { label: "Workflows live", value: "112", delta: "+9", up: true },
];

const trend = [
  { m: "Feb", v: 32 }, { m: "Mar", v: 38 }, { m: "Apr", v: 41 },
  { m: "May", v: 47 }, { m: "Jun", v: 53 }, { m: "Jul", v: 61 },
];

const workflowStatus: [string, string][] = [
  ["lead-intake.flow", "Healthy"],
  ["booking-agent.flow", "Healthy"],
  ["invoice-sync.flow", "Degraded"],
  ["support-bot.flow", "Healthy"],
];

const clients = [
  { name: "Harbor Realty Group", plan: "Growth", status: "Active", workflows: 5 },
  { name: "Meridian Dental", plan: "Starter", status: "Active", workflows: 1 },
  { name: "Voss & Kline Law", plan: "Enterprise", status: "Onboarding", workflows: 8 },
  { name: "Coastal Logistics Co.", plan: "Growth", status: "Active", workflows: 4 },
  { name: "Bright Path Clinic", plan: "Starter", status: "Paused", workflows: 1 },
];

export default function Overview() {
  return (
    <div className="space-y-6">
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((s) => (
          <StatCard key={s.label} {...s} />
        ))}
      </div>

      <div className="grid lg:grid-cols-3 gap-4">
        <Card className="lg:col-span-2">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold text-sm">Revenue trend</h3>
            <button className="flex items-center gap-1 text-xs" style={{ color: "var(--muted)" }}>
              Last 6 months <ChevronDown size={12} />
            </button>
          </div>
          <ResponsiveContainer width="100%" height={200}>
            <LineChart data={trend}>
              <XAxis dataKey="m" tick={{ fontSize: 11, fill: "var(--muted)" }} axisLine={false} tickLine={false} />
              <Tooltip contentStyle={{ background: "var(--surface)", border: "1px solid var(--border)", fontSize: 12 }} />
              <Line type="monotone" dataKey="v" stroke={ACCENT} strokeWidth={2} dot={false} />
            </LineChart>
          </ResponsiveContainer>
        </Card>

        <Card>
          <h3 className="font-semibold text-sm mb-4">Workflow status</h3>
          <div className="space-y-3 font-mono text-xs">
            {workflowStatus.map(([name, status]) => (
              <div key={name} className="flex items-center justify-between">
                <span style={{ color: "var(--muted)" }}>{name}</span>
                <span style={{ color: status === "Healthy" ? "#3FBF7F" : "#F0B429" }}>{status.toLowerCase()}</span>
              </div>
            ))}
          </div>
        </Card>
      </div>

      <Card className="p-0 overflow-hidden">
        <div className="px-5 py-4 flex items-center justify-between" style={{ borderBottom: "1px solid var(--border)" }}>
          <h3 className="font-semibold text-sm">Clients</h3>
          <button style={{ color: ACCENT }} className="text-xs font-medium">View all</button>
        </div>
        <table className="w-full text-sm">
          <thead>
            <tr style={{ color: "var(--muted)" }} className="text-left text-xs">
              <th className="px-5 py-2 font-normal">Client</th>
              <th className="px-5 py-2 font-normal">Plan</th>
              <th className="px-5 py-2 font-normal">Status</th>
              <th className="px-5 py-2 font-normal">Workflows</th>
            </tr>
          </thead>
          <tbody>
            {clients.map((c) => (
              <tr key={c.name} style={{ borderTop: "1px solid var(--border)" }}>
                <td className="px-5 py-3 font-medium">{c.name}</td>
                <td className="px-5 py-3" style={{ color: "var(--muted)" }}>{c.plan}</td>
                <td className="px-5 py-3">
                  <Badge color={STATUS_COLORS[c.status] ?? ACCENT}>{c.status}</Badge>
                </td>
                <td className="px-5 py-3 font-mono" style={{ color: "var(--muted)" }}>{c.workflows}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>
    </div>
  );
}
