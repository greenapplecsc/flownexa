import { useParams } from "react-router-dom";
import { Plus } from "lucide-react";
import Card from "@/components/ui/Card";
import Button from "@/components/ui/Button";
import Badge from "@/components/ui/Badge";
import { CMS_MODULES } from "@/admin/data/cmsModules";
import { STATUS_COLORS, ACCENT } from "@/utils/tokens";

/**
 * One table renderer for every "list of records" admin module
 * (Website Content, Services, Pricing, FAQs, Case Studies, Blog,
 * Testimonials, Team, Leads, Enquiries, Demo Requests, Media,
 * Users, Roles & Permissions). Each module only supplies data —
 * the markup, styling, and interactions live here once.
 */
export default function GenericCmsPage() {
  const { moduleKey } = useParams<{ moduleKey: string }>();
  const config = moduleKey ? CMS_MODULES[moduleKey] : undefined;

  if (!config) {
    return <p style={{ color: "var(--muted)" }}>Module not found.</p>;
  }

  return (
    <div className="space-y-5">
      <div className="flex items-start justify-between gap-4 flex-wrap">
        <div>
          <h1 className="font-display text-xl font-semibold">{config.title}</h1>
          <p className="text-sm mt-1" style={{ color: "var(--muted)" }}>{config.description}</p>
        </div>
        <Button variant="primary">
          <Plus size={14} /> Add new
        </Button>
      </div>

      <Card className="p-0 overflow-hidden">
        <table className="w-full text-sm">
          <thead>
            <tr style={{ color: "var(--muted)", borderBottom: "1px solid var(--border)" }} className="text-left text-xs">
              {config.columns.map((col) => (
                <th key={col.key} className="px-5 py-3 font-normal">{col.label}</th>
              ))}
              <th className="px-5 py-3 font-normal text-right">Actions</th>
            </tr>
          </thead>
          <tbody>
            {config.rows.map((row, i) => (
              <tr key={i} style={{ borderTop: i === 0 ? "none" : "1px solid var(--border)" }}>
                {config.columns.map((col) => (
                  <td key={col.key} className="px-5 py-3">
                    {col.isBadge ? (
                      <Badge color={STATUS_COLORS[String(row[col.key])] ?? ACCENT}>{row[col.key]}</Badge>
                    ) : (
                      <span className={col.key === Object.keys(row)[0] ? "font-medium" : ""} style={{ color: "var(--text)" }}>
                        {row[col.key]}
                      </span>
                    )}
                  </td>
                ))}
                <td className="px-5 py-3 text-right">
                  <button className="text-xs font-medium" style={{ color: ACCENT }}>Edit</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>
    </div>
  );
}
