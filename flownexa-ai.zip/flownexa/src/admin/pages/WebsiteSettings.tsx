import { useState } from "react";
import Card from "@/components/ui/Card";
import Button from "@/components/ui/Button";

const fields: { key: string; label: string; placeholder: string }[] = [
  { key: "siteName", label: "Site name", placeholder: "FlowNexa AI" },
  { key: "tagline", label: "Tagline", placeholder: "Automate Smarter. Scale Faster." },
  { key: "contactEmail", label: "Contact email", placeholder: "hello@flownexa.ai" },
  { key: "calendlyUrl", label: "Booking link (Calendly)", placeholder: "https://calendly.com/flownexa/intro" },
];

export default function WebsiteSettings() {
  const [values, setValues] = useState<Record<string, string>>({});
  const [maintenance, setMaintenance] = useState(false);

  return (
    <div className="space-y-5 max-w-2xl">
      <div>
        <h1 className="font-display text-xl font-semibold">Website Settings</h1>
        <p className="text-sm mt-1" style={{ color: "var(--muted)" }}>
          General configuration for the public-facing site.
        </p>
      </div>

      <Card className="space-y-4">
        {fields.map((f) => (
          <div key={f.key}>
            <label className="text-xs font-medium block mb-1.5" style={{ color: "var(--muted)" }}>{f.label}</label>
            <input
              value={values[f.key] ?? ""}
              onChange={(e) => setValues((v) => ({ ...v, [f.key]: e.target.value }))}
              placeholder={f.placeholder}
              className="w-full px-3 py-2.5 rounded-lg text-sm outline-none"
              style={{ background: "var(--bg)", border: "1px solid var(--border)", color: "var(--text)" }}
            />
          </div>
        ))}

        <label className="flex items-center gap-2 text-sm">
          <input type="checkbox" checked={maintenance} onChange={(e) => setMaintenance(e.target.checked)} />
          Enable maintenance mode
        </label>

        <Button variant="primary">Save changes</Button>
      </Card>
    </div>
  );
}
