import { useState, type FormEvent } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { Sparkles, Lock } from "lucide-react";
import Card from "@/components/ui/Card";
import Button from "@/components/ui/Button";
import ThemeToggle from "@/components/ui/ThemeToggle";
import { useAuth } from "@/context/AuthContext";
import { ACCENT } from "@/utils/tokens";

export default function Login() {
  const { login } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const redirectTo = (location.state as { from?: string })?.from ?? "/admin";

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setError("");
    setLoading(true);
    const result = await login(email, password);
    setLoading(false);
    if (result.ok) {
      navigate(redirectTo, { replace: true });
    } else {
      setError(result.error ?? "Login failed.");
    }
  };

  return (
    <div
      style={{ background: "var(--bg)", color: "var(--text)", minHeight: "100vh" }}
      className="font-body flex flex-col items-center justify-center px-6 relative"
    >
      <div className="absolute top-6 right-6">
        <ThemeToggle />
      </div>

      <div className="flex items-center gap-2 mb-8">
        <div style={{ background: ACCENT }} className="w-8 h-8 rounded-md flex items-center justify-center">
          <Sparkles size={18} color="#fff" />
        </div>
        <span className="font-display font-semibold text-xl">
          FlowNexa <span style={{ color: ACCENT }}>AI</span>
        </span>
      </div>

      <Card className="w-full max-w-sm">
        <div className="flex items-center gap-2 mb-1">
          <Lock size={16} style={{ color: ACCENT }} />
          <h1 className="font-display font-semibold text-lg">Admin sign in</h1>
        </div>
        <p className="text-sm mb-6" style={{ color: "var(--muted)" }}>
          Demo credentials: admin@flownexa.ai / flownexa2026
        </p>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="text-xs font-medium block mb-1.5" style={{ color: "var(--muted)" }}>Email</label>
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full px-3 py-2.5 rounded-lg text-sm outline-none"
              style={{ background: "var(--bg)", border: "1px solid var(--border)", color: "var(--text)" }}
              placeholder="you@company.com"
            />
          </div>
          <div>
            <label className="text-xs font-medium block mb-1.5" style={{ color: "var(--muted)" }}>Password</label>
            <input
              type="password"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full px-3 py-2.5 rounded-lg text-sm outline-none"
              style={{ background: "var(--bg)", border: "1px solid var(--border)", color: "var(--text)" }}
              placeholder="••••••••"
            />
          </div>

          {error && <p className="text-xs" style={{ color: "#E5484D" }}>{error}</p>}

          <Button type="submit" variant="primary" className="w-full justify-center" disabled={loading}>
            {loading ? "Signing in..." : "Sign in"}
          </Button>
        </form>
      </Card>
    </div>
  );
}
