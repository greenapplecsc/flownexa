import {
  ArrowRight, Bot, PhoneCall, MessageSquare, Workflow, Mail,
  CalendarCheck, Building2, Stethoscope, Scale, ShoppingCart, Check,
} from "lucide-react";
import Button from "@/components/ui/Button";
import Card from "@/components/ui/Card";
import SectionHeading from "@/components/ui/SectionHeading";
import FlowPulse from "@/components/FlowPulse";
import { ACCENT } from "@/utils/tokens";

const services = [
  { icon: Bot, name: "AI Chatbots", desc: "Always-on conversations that qualify and convert." },
  { icon: MessageSquare, name: "WhatsApp Automation", desc: "Reach customers where they already message." },
  { icon: PhoneCall, name: "AI Calling Agents", desc: "Natural-sounding calls that book and follow up." },
  { icon: Workflow, name: "Workflow Automation", desc: "Connect your tools so work moves without you." },
  { icon: Mail, name: "Email Automation", desc: "Replies and sequences that sound like your team." },
  { icon: CalendarCheck, name: "Appointment Booking", desc: "Calendars that fill themselves, correctly." },
];

const industries = [
  { icon: Building2, name: "Real Estate" },
  { icon: Stethoscope, name: "Healthcare" },
  { icon: Scale, name: "Legal" },
  { icon: ShoppingCart, name: "E-commerce" },
];

const plans = [
  { name: "Starter", price: "$1,900", cadence: "/mo", blurb: "One automation, done right.", features: ["1 AI workflow", "Email + chat support", "Monthly optimization"] },
  { name: "Growth", price: "$4,500", cadence: "/mo", blurb: "For teams scaling outbound and support.", features: ["Up to 5 workflows", "Priority support", "Dedicated strategist", "Custom integrations"], featured: true },
  { name: "Enterprise", price: "Custom", cadence: "", blurb: "Multi-region, multi-team automation.", features: ["Unlimited workflows", "SLA-backed uptime", "Solutions architect", "Security review"] },
];

export default function Home() {
  return (
    <>
      {/* Hero */}
      <section className="px-6 md:px-12 pt-16 md:pt-24 pb-20 grid md:grid-cols-2 gap-12 items-center max-w-6xl mx-auto">
        <div>
          <div className="font-mono text-xs tracking-widest uppercase mb-4" style={{ color: ACCENT }}>
            Automation Agency
          </div>
          <h1 className="font-display text-4xl md:text-5xl font-semibold leading-tight tracking-tight mb-5">
            Automate smarter.<br />Scale faster.
          </h1>
          <p className="text-base md:text-lg mb-8 max-w-md" style={{ color: "var(--muted)" }}>
            FlowNexa builds AI chatbots, voice agents, and workflow systems that run your business's busywork —
            so your team runs the business.
          </p>
          <div className="flex flex-wrap gap-3">
            <Button variant="primary">
              Book a strategy call <ArrowRight size={15} />
            </Button>
            <Button variant="outline">View demo projects</Button>
          </div>
        </div>
        <div className="flex justify-center md:justify-end">
          <Card className="w-full">
            <div className="font-mono text-xs mb-4" style={{ color: "var(--muted)" }}>
              live workflow · preview
            </div>
            <FlowPulse />
          </Card>
        </div>
      </section>

      {/* Logos strip */}
      <div className="px-6 md:px-12 py-6" style={{ borderTop: "1px solid var(--border)", borderBottom: "1px solid var(--border)" }}>
        <div className="max-w-6xl mx-auto flex flex-wrap justify-between gap-6 text-sm font-mono" style={{ color: "var(--muted)" }}>
          <span>USA</span><span>Canada</span><span>UK</span><span>Australia</span><span>Europe</span>
        </div>
      </div>

      {/* Services */}
      <section id="services" className="px-6 md:px-12 py-20 max-w-6xl mx-auto">
        <SectionHeading eyebrow="Services" title="What we automate" />
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {services.map((s) => (
            <Card key={s.name} hover>
              <s.icon size={20} style={{ color: ACCENT }} className="mb-4" />
              <h3 className="font-semibold mb-1.5">{s.name}</h3>
              <p className="text-sm" style={{ color: "var(--muted)" }}>{s.desc}</p>
            </Card>
          ))}
        </div>
      </section>

      {/* Industries */}
      <section id="industries" className="px-6 md:px-12 py-16 max-w-6xl mx-auto">
        <SectionHeading eyebrow="Industries" title="Built for how you actually work" />
        <div className="grid grid-cols-2 md:grid-cols-4 gap-5">
          {industries.map((ind) => (
            <Card key={ind.name} hover className="flex flex-col items-center text-center gap-3">
              <ind.icon size={22} style={{ color: ACCENT }} />
              <span className="text-sm font-medium">{ind.name}</span>
            </Card>
          ))}
        </div>
      </section>

      {/* Pricing */}
      <section id="pricing" className="px-6 md:px-12 py-20 max-w-6xl mx-auto">
        <SectionHeading eyebrow="Pricing" title="Plans that scale with you" />
        <div className="grid md:grid-cols-3 gap-6">
          {plans.map((p) => (
            <div
              key={p.name}
              className="rounded-2xl p-7 flex flex-col"
              style={{
                background: p.featured ? ACCENT : "var(--surface)",
                border: `1px solid ${p.featured ? ACCENT : "var(--border)"}`,
                color: p.featured ? "#fff" : "var(--text)",
              }}
            >
              <span className="text-sm font-medium mb-2" style={{ color: p.featured ? "#E4E1FF" : "var(--muted)" }}>
                {p.name}
              </span>
              <div className="font-display text-3xl font-semibold mb-1">
                {p.price}
                <span className="text-base font-normal">{p.cadence}</span>
              </div>
              <p className="text-sm mb-6" style={{ color: p.featured ? "#E4E1FF" : "var(--muted)" }}>{p.blurb}</p>
              <ul className="space-y-2.5 mb-8 flex-1">
                {p.features.map((f) => (
                  <li key={f} className="flex items-center gap-2 text-sm">
                    <Check size={14} /> {f}
                  </li>
                ))}
              </ul>
              <button
                className="w-full py-2.5 rounded-full text-sm font-medium"
                style={{ background: p.featured ? "#fff" : ACCENT, color: p.featured ? ACCENT : "#fff" }}
              >
                Get started
              </button>
            </div>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section className="px-6 md:px-12 py-20">
        <Card className="max-w-4xl mx-auto p-10 md:p-14 text-center">
          <h2 className="font-display text-3xl font-semibold tracking-tight mb-3">Ready to remove the busywork?</h2>
          <p className="mb-8" style={{ color: "var(--muted)" }}>
            Book a 20-minute call. We'll map one workflow you can automate this month.
          </p>
          <div className="flex justify-center">
            <Button variant="primary">
              Book a strategy call <ArrowRight size={15} />
            </Button>
          </div>
        </Card>
      </section>
    </>
  );
}
