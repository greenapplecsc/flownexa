import { Link } from "react-router-dom";
import Button from "@/components/ui/Button";

export default function NotFound() {
  return (
    <div
      style={{ background: "var(--bg)", color: "var(--text)", minHeight: "100vh" }}
      className="font-body flex flex-col items-center justify-center px-6 text-center"
    >
      <span className="font-mono text-sm mb-3" style={{ color: "var(--muted)" }}>404</span>
      <h1 className="font-display text-3xl font-semibold mb-3">Page not found</h1>
      <p className="mb-8" style={{ color: "var(--muted)" }}>The page you're looking for doesn't exist.</p>
      <Link to="/">
        <Button variant="primary">Back to home</Button>
      </Link>
    </div>
  );
}
