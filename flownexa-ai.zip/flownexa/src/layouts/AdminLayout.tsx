import { NavLink, Outlet, useNavigate } from "react-router-dom";
import { Bell, LogOut, Search } from "lucide-react";
import ThemeToggle from "@/components/ui/ThemeToggle";
import { useAuth } from "@/context/AuthContext";
import { ACCENT } from "@/utils/tokens";
import { ADMIN_NAV } from "@/admin/data/navConfig";

export default function AdminLayout() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate("/admin/login", { replace: true });
  };

  return (
    <div style={{ background: "var(--bg)", color: "var(--text)", minHeight: "100vh" }} className="flex font-body">
      {/* Sidebar */}
      <aside
        style={{ background: "var(--sidebar)", borderRight: "1px solid var(--border)" }}
        className="w-64 hidden md:flex flex-col shrink-0 sticky top-0 h-screen overflow-y-auto"
      >
        <div className="px-5 py-5 flex items-center gap-2" style={{ borderBottom: "1px solid var(--border)" }}>
          <div style={{ background: ACCENT }} className="w-7 h-7 rounded-md flex items-center justify-center">
            <span className="text-white text-xs font-bold">FN</span>
          </div>
          <span className="font-display font-semibold">
            FlowNexa <span style={{ color: "var(--muted)", fontWeight: 400, fontSize: 12 }}>admin</span>
          </span>
        </div>

        <nav className="flex-1 py-4 px-3 space-y-1">
          {ADMIN_NAV.map((section) => (
            <NavLink
              key={section.path}
              to={section.path}
              end={section.path === "/admin"}
              className={({ isActive }) =>
                `flex items-center gap-3 px-3 py-2 rounded-lg text-sm transition-colors ${isActive ? "font-medium" : ""}`
              }
              style={({ isActive }) => ({
                background: isActive ? "var(--border)" : "transparent",
                color: isActive ? ACCENT : "var(--text)",
              })}
            >
              <section.icon size={16} /> {section.label}
            </NavLink>
          ))}
        </nav>

        <div className="p-4 flex items-center justify-between" style={{ borderTop: "1px solid var(--border)" }}>
          <div className="flex items-center gap-2 min-w-0">
            <div style={{ background: ACCENT }} className="w-8 h-8 rounded-full flex items-center justify-center text-white text-xs font-semibold shrink-0">
              {user?.name?.[0]?.toUpperCase() ?? "A"}
            </div>
            <div className="min-w-0">
              <div className="text-sm font-medium truncate">{user?.name}</div>
              <div className="text-xs truncate" style={{ color: "var(--muted)" }}>{user?.role}</div>
            </div>
          </div>
          <button onClick={handleLogout} aria-label="Log out" style={{ color: "var(--muted)" }}>
            <LogOut size={16} />
          </button>
        </div>
      </aside>

      {/* Main */}
      <div className="flex-1 min-w-0">
        <header style={{ borderBottom: "1px solid var(--border)" }} className="flex items-center justify-between px-6 py-4">
          <div
            className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-full text-sm"
            style={{ border: "1px solid var(--border)" }}
          >
            <Search size={14} style={{ color: "var(--muted)" }} />
            <input placeholder="Search..." className="bg-transparent outline-none text-sm w-40" style={{ color: "var(--text)" }} />
          </div>
          <div className="flex items-center gap-3">
            <button style={{ border: "1px solid var(--border)" }} className="w-9 h-9 rounded-full flex items-center justify-center">
              <Bell size={15} />
            </button>
            <ThemeToggle />
          </div>
        </header>

        <main className="p-6">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
