import { useState } from "react";
import { Outlet, Link } from "react-router-dom";
import { Sparkles, ArrowRight, Menu, X } from "lucide-react";
import ThemeToggle from "@/components/ui/ThemeToggle";
import Button from "@/components/ui/Button";
import { ACCENT } from "@/utils/tokens";

export default function PublicLayout() {
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <div style={{ background: "var(--bg)", color: "var(--text)", minHeight: "100vh" }} className="font-body">
      <header className="sticky top-0 z-50 backdrop-blur" style={{ borderBottom: "1px solid var(--border)" }}>
        <div
          style={{ background: "color-mix(in srgb, var(--bg) 85%, transparent)" }}
          className="flex items-center justify-between px-6 md:px-12 py-4"
        >
          <Link to="/" className="flex items-center gap-2">
            <div style={{ background: ACCENT }} className="w-7 h-7 rounded-md flex items-center justify-center">
              <Sparkles size={16} color="#fff" />
            </div>
            <span className="font-display font-semibold text-lg tracking-tight">
              FlowNexa <span style={{ color: ACCENT }}>AI</span>
            </span>
          </Link>

          <nav className="hidden md:flex items-center gap-8 text-sm" style={{ color: "var(--muted)" }}>
            <a href="/#services" className="hover:opacity-80">Services</a>
            <a href="/#industries" className="hover:opacity-80">Industries</a>
            <a href="/#pricing" className="hover:opacity-80">Pricing</a>
            <a href="/#" className="hover:opacity-80">Case Studies</a>
            <a href="/#" className="hover:opacity-80">About</a>
          </nav>

          <div className="flex items-center gap-3">
            <ThemeToggle />
            <Button variant="primary" className="hidden md:inline-flex">
              Book a call <ArrowRight size={14} />
            </Button>
            <button className="md:hidden" onClick={() => setMenuOpen(!menuOpen)} style={{ color: "var(--text)" }}>
              {menuOpen ? <X size={20} /> : <Menu size={20} />}
            </button>
          </div>
        </div>

        {menuOpen && (
          <div className="md:hidden px-6 pb-4 flex flex-col gap-3 text-sm" style={{ color: "var(--muted)" }}>
            <a href="/#services">Services</a>
            <a href="/#industries">Industries</a>
            <a href="/#pricing">Pricing</a>
          </div>
        )}
      </header>

      <main>
        <Outlet />
      </main>

      <footer className="px-6 md:px-12 py-10" style={{ borderTop: "1px solid var(--border)", color: "var(--muted)" }}>
        <div className="max-w-6xl mx-auto flex flex-col md:flex-row justify-between gap-4 text-sm">
          <span className="font-mono">© {new Date().getFullYear()} FlowNexa AI</span>
          <div className="flex gap-6">
            <a href="/#" className="hover:opacity-80">Privacy Policy</a>
            <a href="/#" className="hover:opacity-80">Terms</a>
            <a href="/#" className="hover:opacity-80">Contact</a>
          </div>
        </div>
      </footer>
    </div>
  );
}
