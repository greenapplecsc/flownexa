import { Routes, Route } from "react-router-dom";
import PublicLayout from "@/layouts/PublicLayout";
import AdminLayout from "@/layouts/AdminLayout";
import Home from "@/pages/Home";
import NotFound from "@/pages/NotFound";
import Login from "@/admin/pages/Login";
import Overview from "@/admin/pages/Overview";
import GenericCmsPage from "@/admin/pages/GenericCmsPage";
import SeoSettings from "@/admin/pages/SeoSettings";
import WebsiteSettings from "@/admin/pages/WebsiteSettings";
import ProtectedRoute from "./ProtectedRoute";

export default function AppRoutes() {
  return (
    <Routes>
      {/* Public site */}
      <Route element={<PublicLayout />}>
        <Route path="/" element={<Home />} />
      </Route>

      {/* Admin login — unprotected */}
      <Route path="/admin/login" element={<Login />} />

      {/* Admin dashboard — protected */}
      <Route
        path="/admin"
        element={
          <ProtectedRoute>
            <AdminLayout />
          </ProtectedRoute>
        }
      >
        <Route index element={<Overview />} />
        <Route path="seo" element={<SeoSettings />} />
        <Route path="settings" element={<WebsiteSettings />} />
        {/* All 14 table-based modules (content, services, pricing, faqs,
            case-studies, blog, testimonials, team, leads, enquiries,
            demo-requests, media, users, roles) share one renderer. */}
        <Route path=":moduleKey" element={<GenericCmsPage />} />
      </Route>

      <Route path="*" element={<NotFound />} />
    </Routes>
  );
}
