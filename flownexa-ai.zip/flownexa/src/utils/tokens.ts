// Shared brand tokens — same values across public site and admin dashboard.
export const ACCENT = "#5B4FE9";
export const AMBER = "#F0B429";
export const SUCCESS = "#3FBF7F";
export const DANGER = "#E5484D";

export const STATUS_COLORS: Record<string, string> = {
  Active: SUCCESS,
  Healthy: SUCCESS,
  Onboarding: AMBER,
  Degraded: AMBER,
  Paused: "#8A8797",
  New: ACCENT,
};
