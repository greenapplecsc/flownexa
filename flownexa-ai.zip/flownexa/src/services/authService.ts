export interface AdminUser {
  name: string;
  email: string;
  role: "Admin" | "Editor";
}

// Demo credentials for local development. Replace this function body with a
// real API call (e.g. fetch("/api/auth/login")) when a backend is available.
const DEMO_EMAIL = "admin@flownexa.ai";
const DEMO_PASSWORD = "flownexa2026";

export async function loginRequest(
  email: string,
  password: string
): Promise<{ ok: boolean; user?: AdminUser; error?: string }> {
  await new Promise((resolve) => setTimeout(resolve, 400)); // simulate network latency

  if (email.trim().toLowerCase() === DEMO_EMAIL && password === DEMO_PASSWORD) {
    return { ok: true, user: { name: "mk", email: DEMO_EMAIL, role: "Admin" } };
  }
  return { ok: false, error: "Invalid email or password." };
}
