# FlowNexa AI — merged project

Single React + Vite + TypeScript app containing both the public website and
the admin dashboard.

## Run locally

```bash
npm install
npm run dev
```

Then open the URL Vite prints (typically http://localhost:5173).

## Routes

- `/` — public website (Home)
- `/admin/login` — admin sign in
- `/admin` — dashboard overview (protected)
- `/admin/content`, `/admin/services`, `/admin/pricing`, `/admin/faqs`,
  `/admin/case-studies`, `/admin/blog`, `/admin/testimonials`, `/admin/team`,
  `/admin/leads`, `/admin/enquiries`, `/admin/demo-requests`, `/admin/media`,
  `/admin/seo`, `/admin/settings`, `/admin/users`, `/admin/roles` — all
  protected, all reachable from the admin sidebar

## Demo admin login

```
Email:    admin@flownexa.ai
Password: flownexa2026
```

Auth is a local mock in `src/services/authService.ts` — swap its body for a
real API call whenever a backend is ready; nothing else needs to change since
`AuthContext` and `ProtectedRoute` only depend on that function's shape.

## Structure

```
src/
  components/    shared UI atoms (Button, Card, Badge, StatCard, ThemeToggle...)
  layouts/       PublicLayout (nav+footer), AdminLayout (sidebar+topbar)
  pages/         public pages (Home, NotFound)
  admin/         admin pages + the CMS module config/data they render from
  routes/        AppRoutes + ProtectedRoute
  context/       ThemeContext (shared dark/light), AuthContext (admin auth)
  services/      authService (swap for real API)
  utils/         tokens.ts (brand colors), cn.ts (classnames helper)
  styles/        globals.css (Tailwind + theme CSS variables)
```

## Notes

- Theme (dark/light) is shared app-wide via `ThemeContext` and CSS variables
  in `src/styles/globals.css`, so toggling it on the public site or in the
  admin dashboard is consistent everywhere.
- The 14 list-style admin sections (Content, Services, Pricing, FAQs, Case
  Studies, Blog, Testimonials, Team, Leads, Enquiries, Demo Requests, Media,
  Users, Roles) all render through one component, `GenericCmsPage`, driven by
  config in `src/admin/data/cmsModules.ts` — add a new module by adding an
  entry there plus a sidebar link in `src/admin/data/navConfig.ts`.
- SEO Settings and Website Settings are separate simple form pages since
  they're key/value settings, not record lists.
